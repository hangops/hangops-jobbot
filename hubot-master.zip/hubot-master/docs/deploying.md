---
permalink: /docs/deploying/index.html
layout: docs
---

- [Azure](/docs/deploying/azure.md)
- [Bluemix](/docs/deploying/bluemix.md)
- [Heroku](/docs/deploying/heroku.md)
- [Unix](/docs/deploying/unix.md)
- [Windows](/docs/deploying/windows.md)
